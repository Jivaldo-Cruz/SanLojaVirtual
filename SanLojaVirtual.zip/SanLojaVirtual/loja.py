from tkinter import *
import pyperclip # para fazer copia de valores
import os

#----------------------------------------------
# GUI
root = Tk()

#----------------------------------------------
class pagePrincipal(Frame):
    def __init__(self, master):
        super().__init__()
        self.root = root

        self.altura = self.root.winfo_screenwidth()
        self.largura = self.root.winfo_screenheight()
        self.center_x = int(self.altura/2) - int(1280/2)
        self.center_y = int(self.largura/2) - int(720/2)

        self.root.geometry(f"1280x720+{self.center_x}+{self.center_y}")
        self.root.title("Loja SanCode")
        
        self.frame_tela()
        self.menuSecundario()
        self.menuPrincipal()

        self.root.mainloop()

    #----------------------------------------------
    # Parte lógico
    def covid19(self):
        if(os.name == "nt"):
            os.system("python3 covid19/san_covid19(Windows).py")
        else:
            os.system("python3 covid19/'san_covid19(linux).py'")

    def fechar(self):
        self.root.destroy()
    
    def destruir(self):
        for widget in self.frameB.winfo_children():
            widget.destroy()
        self.frameB.pack_forget()

    #----------------------------------------------
    # Frame
    def frame_tela(self):
        self.frameA = Frame(self.root)
        self.frameB = Frame(self.root)
        self.frameB.place(relx = 0.2, relwidth = 0.8, relheight = 1)
        self.frameA.place(relx = 0, relwidth = 0.2, relheight = 1)

        self.main()# o main vai executar antes de qualquer coisa, pq é o principal

    #----------------------------------------------
    # Menu horizontal
    def menuSecundario(self):
        self.menu_s = Menu(self.root)
        self.file_menu = Menu(self.menu_s, tearoff = 0)
        self.edit_menu = Menu(self.menu_s, tearoff = 0)
        self.opcao_menu = Menu(self.menu_s, tearoff = 0)
        self.help_menu = Menu(self.menu_s, tearoff = 0)
        self.covid_menu = Menu(self.menu_s, tearoff = 0)

        self.file_menu.add_command(label = "New")
        self.file_menu.add_command(label = "Open")
        self.file_menu.add_command(label = "Save")
        self.file_menu.add_separator()
        self.file_menu.add_command(label = "Exit", command = lambda: self.fechar())
        self.menu_s.add_cascade(label = "File", menu = self.file_menu)

        self.edit_menu.add_command(label = "Cut")
        self.edit_menu.add_command(label = "Copy")
        self.edit_menu.add_command(label = "Paste")
        self.menu_s.add_cascade(label = "Edit", menu = self.edit_menu)

        self.opcao_menu.add_command(label = "Configuração")
        self.menu_s.add_cascade(label = "Option", menu = self.opcao_menu)

        self.help_menu.add_command(label = "Nosso Contacto")
        self.menu_s.add_cascade(label = "Help", menu = self.help_menu)

        self.covid_menu.add_command(label = "Saber mais", command = self.covid19)
        self.menu_s.add_cascade(label = "Covid-19", menu = self.covid_menu)

        self.root.config(menu = self.menu_s)
    
    #----------------------------------------------
    # Página Principal
    def main(self):
        self.destruir()
        self.p = Label(self.frameB, text = "Seja bem vindo!", font = "Arial 16 bold")
        self.p.pack(fill = X, expand = 1)
    
    #----------------------------------------------
    # Página contacto
    def contacto(self):
        self.destruir()
        self.legenda = Label(self.frameB,
                            text = "Cadastra-se!",
                            font = "Arial 14 bold",
                            background = "#34abe0",
                            foreground = "#fff")
        self.nome_cadastro = Label(self.frameB,
                                    text = "Nome",
                                    font = "Arial 12")
        self.nome_cadastro_in = Text(self.frameB,
                                    width = 40,
                                    height = 1.5)
        self.email_cadastro = Label(self.frameB,
                                    text = "E-mail",
                                    font = "Arial 12")
        self.email_cadastro_in = Text(self.frameB,
                                    width = 40,
                                    height = 1.5)
        self.numero_cadastro = Label(self.frameB,
                                    text = "Número",
                                    font = "Arial 12")
        self.numero_cadastro_in = Text(self.frameB,
                                    width = 40,
                                    height = 1.5)
        self.senha_cadastro = Label(self.frameB,
                                    text = "Senha",
                                    font = "Arial 12")
        self.senha_cadastro_in = Text(self.frameB,
                                    width = 40,
                                    height = 1.5)
        self.csenha_cadastro = Label(self.frameB,
                                    text = "Confirma senha",
                                    font = "Arial 12")
        self.csenha_cadastro_in = Text(self.frameB,
                                    width = 40,
                                    height = 1.5)
        self.msg_cadastro = Label(self.frameB,
                                    text = "Mensagem",
                                    font = "Arial 12")
        self.msg_cadastro_in = Text(self.frameB,
                                    width = 40,
                                    height = 8)
        self.btn_cadastrar = Button(self.frameB,
                                    text = "Executar!",
                                    font = "Arial 12 bold",
                                    foreground = "#fff",
                                    background = "#414146")
        
        self.legenda.pack(ipadx = 20, ipady = 15, fill = X, side = "top")
        self.nome_cadastro.pack(ipadx = 20, ipady = 5, fill = X, side = "top")
        self.nome_cadastro_in.pack()
        self.email_cadastro.pack(ipadx = 20, ipady = 5, fill = X, side = "top")
        self.email_cadastro_in.pack()
        self.numero_cadastro.pack(ipadx = 20, ipady = 5, fill = X, side = "top")
        self.numero_cadastro_in.pack()
        self.senha_cadastro.pack(ipadx = 20, ipady = 5, fill = X, side = "top")
        self.senha_cadastro_in.pack()
        self.csenha_cadastro.pack(ipadx = 20, ipady = 5, fill = X, side = "top")
        self.csenha_cadastro_in.pack()
        self.msg_cadastro.pack(ipadx = 20, ipady = 5, fill = X, side = "top")
        self.msg_cadastro_in.pack()
        self.btn_cadastrar.pack(ipadx = 113, pady = 2, ipady = 5)

    #----------------------------------------------
    # Página sobre
    def sobre(self):
        self.destruir()
        self.descricao = Label(self.frameB,
        text = """
            Fundado em setembro de 2020, o SanCode tem como objetivo principal compartilhar conhecimentos e informações 
            da área TI, tornando a experiência de estudar através da internet única e satisfatória. 
            
            Com ênfase especial na didática, procuramos ensinar da mesma forma que gostaríamos de 
            aprender, buscando sempre produzir conteúdos diferenciados.

            Fico muito feliz em vê-lo por aqui. Graças a você, o Curso em Vídeo cresceu muito além da minha expectativa!

            Somos referência na internet e fonte de inspiração para muitos 
            outros profissionais, que diariamente vem até aqui em busca de conhecimento e inspiração.
        """, font = "Arial 12")

        self.fundador = Label(self.frameB,
                            text = "Fundador: Jivaldo Da Cruz",
                            font = "Arial 11", bg = "#34abe0", fg = "#ccc", anchor = "e")

        self.descricao.pack(fill = X, expand = 0)
        self.fundador.pack(padx = 80, ipadx = 10, ipady = 5, fill = X, expand = 0)

    #----------------------------------------------
    # Menu vertical
    def menuPrincipal(self):
        self.frameA['background'] = "#414146"
        self.label_btn_1 = Button(
            self.frameA, 
            text = "Home",
            background = "#414146",
            foreground = "#ffffff",
            highlightbackground = "#414146",
            highlightthickness = 1,
            command = lambda: self.main()
        )
        self.label_btn_2 = Button(
            self.frameA, 
            text = "Loja",
            background = "#414146",
            foreground = "#ffffff",
            highlightbackground = "#414146",
            highlightthickness = 1,
            #command = passself.opcao_menu
        )
        self.label_btn_3 = Button(
            self.frameA, 
            text = "Compra",
            background = "#414146",
            foreground = "#ffffff",
            highlightbackground = "#414146",
            highlightthickness = 1,
            #command = pass
        )
        self.label_btn_4 = Button(
            self.frameA, 
            text = "Contacto",
            background = "#414146",
            foreground = "#ffffff",
            highlightbackground = "#414146",
            highlightthickness = 1,
            command = lambda: self.contacto()
        )
        self.label_btn_5 = Button(
            self.frameA, 
            text = "Sobre",
            background = "#414146",
            foreground = "#ffffff",
            highlightbackground = "#414146",
            highlightthickness = 1,
            command = lambda: self.sobre()
        )
        self.label_text = Label(
            self.frameA, 
            text = " @2020 \n SanSoft",
            background = "#414146",
            foreground = "#ffffff"
        )


        self.label_btn_1.pack(ipadx = 20, ipady = 15, fill = X, side = "top")
        self.label_btn_2.pack(ipadx = 20, ipady = 15, fill = X, side = "top")
        self.label_btn_3.pack(ipadx = 20, ipady = 15, fill = X, side = "top")
        self.label_btn_4.pack(ipadx = 20, ipady = 15, fill = X, side = "top")
        self.label_btn_5.pack(ipadx = 20, ipady = 15, fill = X, side = "top")
        self.label_text.pack(ipadx = 20, ipady = 15, fill = X, side = "bottom")

#----------------------------------------------
pagePrincipal(root)
