from tkinter import *
import sqlite3
from sqlite3 import Error
import numpy as np
import time

#----------------------------------------------
# GUI
root = Tk()

#----------------------------------------------
class Administrador(Frame):
    def __init__(self, master):
        super().__init__()
        self.root = root
        self.root.title("Administrador")
        self.altura = self.root.winfo_screenwidth()
        self.largura = self.root.winfo_screenheight()
        self.center_x = int(self.altura/2) - int(1280/2)
        self.center_y = int(self.largura/2) - int(720/2)
        self.root.geometry(f"1280x720+{self.center_x}+{self.center_y}")

        self.Frame_()
        self.menu_lateral()

        self.conexao = self.db_conexao()# conexão e criação de DB

        self.root.mainloop()

    #----------------------------------------------
    # Base de da dados Admin
    texto_aviso = StringVar()

    #----------------------------------------------
    # Base de da dados Admin
    def db_conexao(self):
        self.caminho = "db/admin.db"
        try:
            self.con = sqlite3.connect(self.caminho)
        except Error as er:
            print(er)
        return self.con

    # criação de tabela
    tsql = """
        CREATE TABLE ADMINISTRADOR_LOJA(
            ID_ADMIN INTEGER PRIMARY KEY AUTOINCREMENT,
            NOME_ADMIN VARCHAR(30),
            EMAIL_ADMIN VARCHAR(40),
            SENHA_ADMIN VARCHAR(30)
        )
    """
    def db_principal(self, conen, sql):
        try:
            c = conen.cursor()
            c.execute(sql)
            conen.commit()
            resultado = c.fetchall()# serve para consultar
            return resultado
        except Error:
            # inserir na tabela
            if(self.c_nome_cdt.get("1.0", END) != "\n"):
                if(self.c_email_cdt.get("1.0", END) != "\n"):
                    if(self.c_senha_cdt.get("1.0",END) != "\n" and self.c_senhac_cdt.get("1.0",END) != "\n"):
                        if(self.c_senha_cdt.get("1.0",END) == self.c_senhac_cdt.get("1.0",END)):
                            self.isql = "INSERT INTO ADMINISTRADOR_LOJA(NOME_ADMIN, EMAIL_ADMIN, SENHA_ADMIN)VALUES('"+self.c_nome_cdt.get("1.0",END)+"', '"+self.c_email_cdt.get("1.0",END)+"', '"+self.c_senha_cdt.get("1.0",END)+"')"
                        else:
                            self.texto_aviso.set("Campo vazio ou senha não conside com a outra!")
                            self.cadastro_admin()
            else:
                self.texto_aviso.set("Campo vazio ou senha não conside com a outra!")
                self.cadastro_admin()
            self.db_principal(self.conexao, self.isql)
            self.destruir()
            self.cadastro_admin()# atualização com biblioteca time e outra página será aberto cá
    # logar com db
    def logarDB(self):
        self.lsql = "SELECT * FROM ADMINISTRADOR_LOJA WHERE EMAIL_ADMIN LIKE '%"+self.c_email_cdt.get("1.0",END)+"%'"

        for i in self.db_principal(self.conexao, self.lsql):
            for x in range(4):
                if(self.c_email_cdt.get("1.0",END) != "\n" and self.c_senha_cdt.get("1.0",END) != "\n"):
                    if(i[x] == self.c_email_cdt.get("1.0",END)):
                        if(i[3] == self.c_senha_cdt.get("1.0",END)):
                            print("Logado com sucesso!")
                            return False# ainda por acabar com uma função
        print("Email ou senha incorreto!")
    #----------------------------------------------
    # Destruir
    def destruir(self):
        for x in self.frameB.winfo_children():
            x.destroy()
        self.frameB.pack_forget()

    #----------------------------------------------
    # frame
    def Frame_(self):
        self.frameA = Frame(self.root, bg = "#414146")
        self.frameB = Frame(self.root)

        self.alerta = Label(self.frameB,
                            text = "Página somente para administradores!",
                            font = "Verdana 14")
        self.alerta.pack(fill = X, expand = 1)

        self.frameA.place(relheight = 1, relwidth = 0.2)
        self.frameB.place(relx = 0.2, relheight = 1, relwidth = 0.8)

    #----------------------------------------------
    # Cadastro de admin
    def login_admin(self):
        self.destruir()
        self.legenda_2 = Label(self.frameB,
                                text = "Loga-se!",
                                font = "Verdana 14 bold",
                                background = "#34abe0",
                                foreground = "#fff")
        self.email_cdt = Label(self.frameB,
                                text = "Email",
                                font = "Arial 12")
        self.senha_cdt = Label(self.frameB,
                                text = "Senha",
                                font = "Arial 12")
        self.c_email_cdt = Text(self.frameB,
                                width = 40,
                                height = 1.5)
        self.c_senha_cdt = Text(self.frameB,
                                width = 40,
                                height = 1.5)
        self.btn_cdt = Button(self.frameB,
                            text = "Cadastrar",
                            foreground = "#fff",
                            background = "#414146",
                            command = lambda: self.logarDB())

        self.legenda_2.pack(ipady = 15, fill = X, side = "top")
        self.email_cdt.pack(ipady = 15, fill = X, side = "top")
        self.c_email_cdt.pack()
        self.senha_cdt.pack(ipady = 15, fill = X, side = "top")
        self.c_senha_cdt.pack()
        self.btn_cdt.pack(ipadx = 117, ipady = 10, pady = 5, side = "top")

    #----------------------------------------------
    # Login de admin
    def cadastro_admin(self):
        self.destruir()
        self.legenda_2 = Label(self.frameB,
                                text = "Cadastra-se!",
                                font = "Verdana 14 bold",
                                background = "#34abe0",
                                foreground = "#fff")
        self.nome_cdt = Label(self.frameB,
                            text = "Nome",
                            font = "Arial 12")
        self.email_cdt = Label(self.frameB,
                                text = "Email",
                                font = "Arial 12")
        self.senha_cdt = Label(self.frameB,
                                text = "Senha",
                                font = "Arial 12")
        self.senha_cdt_c = Label(self.frameB,
                                text = "Resc. Senha",
                                font = "Arial 12")
        self.c_nome_cdt = Text(self.frameB,
                                width = 40,
                                height = 1.5)
        self.c_email_cdt = Text(self.frameB,
                                width = 40,
                                height = 1.5,)
        self.c_senha_cdt = Text(self.frameB,
                                width = 40,
                                height = 1.5)
        self.c_senhac_cdt = Text(self.frameB,
                                width = 40,
                                height = 1.5)
        self.btn_cdt = Button(self.frameB,
                            text = "Cadastrar",
                            foreground = "#fff",
                            background = "#414146",
                            command = lambda: self.db_principal(self.conexao, self.tsql))
        self.alerta_1 = Label(self.frameB,
                            textvariable = self.texto_aviso,
                            font = "Verdana 14",
                            foreground = "red")
            
        self.legenda_2.pack(ipady = 15, fill = X, side = "top")
        self.nome_cdt.pack(ipady = 15, fill = X, side = "top")
        self.c_nome_cdt.pack()
        self.email_cdt.pack(ipady = 15, fill = X, side = "top")
        self.c_email_cdt.pack()
        self.senha_cdt.pack(ipady = 15, fill = X, side = "top")
        self.c_senha_cdt.pack()
        self.senha_cdt_c.pack(ipady = 15, fill = X, side = "top")
        self.c_senhac_cdt.pack()
        self.btn_cdt.pack(ipadx = 117, ipady = 10, pady = 5, side = "top")
        self.alerta_1.pack(fill = X, expand = 1)

    #----------------------------------------------
    # Login de admin
    def menu_lateral(self):
        self.logar_ltr = Button(self.frameA,
                                text = "Logar",
                                background = "#414146",
                                foreground = "#fff",
                                highlightbackground = "#414146",
                                highlightthickness = 1,
                                command = lambda: self.login_admin())
        self.cadastrar_ltr = Button(self.frameA,
                                text = "Cadastrar",
                                background = "#414146",
                                foreground = "#fff",
                                highlightbackground = "#414146",
                                highlightthickness = 1,
                                command = lambda: self.cadastro_admin())
        
        self.logar_ltr.pack(ipadx = 20, ipady = 15, fill = X, side = "top")
        self.cadastrar_ltr.pack(ipadx = 20, ipady = 15, fill = X, side = "top")

#----------------------------------------------
Administrador(root)
